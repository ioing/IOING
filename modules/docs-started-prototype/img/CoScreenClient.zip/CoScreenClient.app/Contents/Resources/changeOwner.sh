#!/bin/bash
#unzip EShareAudio.zip
#echo $HOME
cp -R "$1" /Library/Extensions/EShareAudio.kext
chmod -R 755 /Library/Extensions/EShareAudio.kext
chown -R root:wheel /Library/Extensions/EShareAudio.kext
kextload /Library/Extensions/EShareAudio.kext
touch /Library/Extensions

